﻿using System;

public class PersonalException : Exception
{
    public PersonalException() : base("My first exception is awesome!!!")
    {

    }
}